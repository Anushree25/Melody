package myecho.com.echo

class  CurrentSongPlayer(){

    var songArtist:String?=null
    var songTitle:String?=null
    var songPath:String?=null
    var songId:Long=0
    var songPosition:Int=0
    var isPlaying:Boolean=false
    var isLoop:Boolean=false
    var shuffleSong:Boolean=false
    var trackPosition:Boolean=false




}