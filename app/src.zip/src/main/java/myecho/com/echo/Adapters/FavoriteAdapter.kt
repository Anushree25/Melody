package myecho.com.echo.Adapters

import android.content.Context
import android.os.Bundle
import android.support.v4.app.FragmentActivity
import android.support.v7.widget.RecyclerView
import android.telecom.Call
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView
import myecho.com.echo.Fragments.SongsPlayingFragment
import myecho.com.echo.Songs

class FavoriteAdapter(songDetails: ArrayList<Songs>,context: Context):RecyclerView.Adapter<FavoriteAdapter.FavSongsViewHolder>(){
    override fun onBindViewHolder(holder: FavSongsViewHolder, position: Int) {

        var songobject=songs_list?.get(position)
        holder?.title?.setText(songobject?.songTitle)
        holder?.artist?.setText(songobject?.artist)
        holder?.layout?.setOnClickListener {

            val songsPlayingFragment= SongsPlayingFragment()
            var obj=Bundle()
            obj.putString("artist",songobject?.artist)
            obj.putString("path",songobject?.details)
            obj.putString("title",songobject?.songTitle)
            obj.putInt("id",songobject?.songId?.toInt() as Int)
            obj.putInt("songPosition",position)
            obj.putParcelableArrayList("songslist",songs_list)
            songsPlayingFragment.arguments=obj
            (mcontext as FragmentActivity).supportFragmentManager.beginTransaction().replace(myecho.com.echo.R.id.details_fragment,songsPlayingFragment)
                    .addToBackStack("SongsPlayingFragment").commit()

        }

    }

    var songs_list:ArrayList<Songs>?=null
    var mcontext:Context?=null

    init {
        this.songs_list=songDetails
        this.mcontext=context

    }

    class FavSongsViewHolder(itemview:View?):RecyclerView.ViewHolder(itemview){

        var title: TextView?=null
        var artist:TextView?=null
        var layout:RelativeLayout?=null

        init {
            title=itemview?.findViewById(myecho.com.echo.R.id.tracktitle)
            artist=itemview?.findViewById(myecho.com.echo.R.id.artist)
            layout=itemview?.findViewById(myecho.com.echo.R.id.content_view)


        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteAdapter.FavSongsViewHolder {

        var itemview=LayoutInflater.from(parent?.context).inflate(myecho.com.echo.R.layout.custom_main_screen_adapter,parent,false)
        var view=  FavoriteAdapter.FavSongsViewHolder(itemview)

        return  view

    }

    override fun getItemCount(): Int {
        if(songs_list!=null) {
            return (songs_list as ArrayList<Songs>).size
        }else{
            return 0
        }


    }





}