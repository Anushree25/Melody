package myecho.com.echo.Fragments

import android.app.Activity
import android.content.Context
import android.graphics.PorterDuff
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.support.transition.Visibility
import android.support.v4.app.Fragment
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.view.*
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.cleveroad.audiovisualization.AudioVisualization
import com.cleveroad.audiovisualization.DbmHandler
import com.cleveroad.audiovisualization.GLAudioVisualizationView
import kotlinx.android.synthetic.main.fragment_songs_playing.*
import myecho.com.echo.*
import myecho.com.echo.Adapters.FavoriteAdapter
import myecho.com.echo.Fragments.SongsPlayingFragment.Statified.currentPosition
import myecho.com.echo.Fragments.SongsPlayingFragment.Statified.mediaPlayer
import myecho.com.echo.Fragments.SongsPlayingFragment.Statified.seekBar

import myecho.com.echo.R.id.seekbar
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 *
 */
class SongsPlayingFragment : Fragment() {


    var mAcceleration: Float = 0f
    var mAccelerationCurrent: Float = 0f
    var mAccelerationLast: Float = 0f

    object Statified {
        var mActivity: Activity? = null
        var mediaPlayer: MediaPlayer? = null
        var shuffleButton: ImageButton? = null
        var loopButton: ImageButton? = null
        var playpauseButton: ImageButton? = null
        var previousButton: ImageButton? = null
        var nextButton: ImageButton? = null
        var currentSongPlayer: CurrentSongPlayer? = null
        var currentPosition: Int = 0
        var fetchList: ArrayList<Songs>? = null
        var songTitle: TextView? = null
        var songArtist: TextView? = null
        var startTime: TextView? = null
        var endTime: TextView? = null
        var audioVisualization: AudioVisualization? = null
        var audioVisualizationView: GLAudioVisualizationView? = null
        var echoDatabase: EchoDatabase? = null
        var favButton: ImageButton? = null
        var seekBar: SeekBar? = null
        /*Sensor Variables*/
        var mSensorManager: SensorManager? = null
        var mSensorListener: SensorEventListener? = null
        var MY_PREFS_NAME = "ShakeFeature"



        var updateSongTime= object:Runnable {
            override fun run() {

                var getCurrent=mediaPlayer?.currentPosition
                startTime?.setText(String.format("%d: %d",
                        TimeUnit.MILLISECONDS.toMinutes(getCurrent?.toLong() as Long),
                        TimeUnit.MILLISECONDS.toSeconds
                        (getCurrent?.toLong()) -TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(getCurrent?.toLong()))))


                //TimeUnit.MILLISECONDS.toSeconds(TimeUnit.MILLISECONDS.toMinutes(getCurrent?.toLong() as Long))))
                seekBar?.setProgress(getCurrent?.toInt() as Int)
                Handler().postDelayed(this,1000)
            }

        }
    }

    object Staticated{
        var MY_PREFS_SHUFFLE="Shuffle feature"
        var MY_PREFS_LOOP="Loop feature"

        fun playNext(check:String){

            seekBar?.setProgress(0);
            if(check.equals("PlayNextNormal",true))
            {
                Statified.currentPosition =  Statified.currentPosition + 1

            } else if (check.equals("PlayNextNormalShuffle",true)){

                var randomObject=Random()
                var randomPosition=randomObject.nextInt(Statified.fetchList?.size?.plus(1)as Int)
                Statified.currentPosition=randomPosition


            }
            if(Statified.currentPosition==Statified.fetchList?.size){

                Statified. currentPosition=0
            }
            var nextSong=Statified.fetchList?.get(Statified.currentPosition)
            Statified.currentSongPlayer?.songPath=nextSong?.details
            Statified.currentSongPlayer?.songTitle=nextSong?.songTitle
            Statified.currentSongPlayer?.songArtist=nextSong?.artist
            Statified.currentSongPlayer?.songId=nextSong?.songId as Long
            updateTextviews(Statified.currentSongPlayer?.songTitle as String,Statified.currentSongPlayer?.songArtist as String)
            Statified.mediaPlayer?.reset()

            try {
                Statified.mediaPlayer?.setDataSource(Statified.mActivity, Uri.parse(Statified.currentSongPlayer?.songPath))
                Statified.mediaPlayer?.prepare()
                ProcessInformation(Statified.mediaPlayer as MediaPlayer)
                Statified. mediaPlayer?.start()

            }catch (e:Exception){

                e.printStackTrace()
            }

            if(Statified.echoDatabase?.checkIfIdExists(Statified.currentSongPlayer?.songId?.toInt() as Int) as Boolean){

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_on)

            }else{

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_off)

            }


        }

        fun playPrevious(){

            seekBar?.setProgress(0);
            Statified.currentPosition=Statified.currentPosition-1

            if(Statified.currentPosition==-1){

                Statified.currentPosition=0
            }

            if(Statified.currentSongPlayer?.isPlaying as Boolean){

                Statified. playpauseButton?.setBackgroundResource(R.mipmap.pause_icon)
            }else{

                Statified.playpauseButton?.setBackgroundResource(R.mipmap.play_icon)
            }

            Statified.currentSongPlayer?.isLoop=false

            var prevSong=Statified.fetchList?.get(Statified.currentPosition)
            Statified. currentSongPlayer?.songPath=prevSong?.details
            Statified.currentSongPlayer?.songTitle=prevSong?.songTitle
            Statified.currentSongPlayer?.songArtist=prevSong?.artist
            Statified.currentSongPlayer?.songId=prevSong?.songId as Long
           updateTextviews(  Statified.currentSongPlayer?.songTitle as String, Statified. currentSongPlayer?.songArtist as String)
            Statified.mediaPlayer?.reset()

            try {
                Statified.mediaPlayer?.setDataSource(Statified.mActivity, Uri.parse(Statified.currentSongPlayer?.songPath))
                Statified.mediaPlayer?.prepare()
                ProcessInformation(Statified.mediaPlayer as MediaPlayer)
                Statified.mediaPlayer?.start()

            }catch (e:Exception){

                e.printStackTrace()
            }

            if(Statified.echoDatabase?.checkIfIdExists(Statified.currentSongPlayer?.songId?.toInt() as Int) as Boolean){

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_on)

            }else{

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_off)

            }
        }


        fun updateTextviews(title:String,artist:String){
            var updatedTitle=title
            var updatedArtist=artist
            if(title.equals("<unknown>",true)){
                updatedTitle="unknown"

            }
            if(artist.equals("<unknown>",true)){

                updatedArtist="unknown"

            }
            Statified.songTitle?.setText(updatedTitle)
            Statified.songArtist?.setText(updatedArtist)
        }

        fun ProcessInformation(mediaPlayer: MediaPlayer){

            val finalTime=mediaPlayer?.duration
            val firstTime=mediaPlayer?.currentPosition
            Statified.seekBar?.max=finalTime

            Statified.startTime?.setText(String.format("%d: %d",
                    TimeUnit.MILLISECONDS.toMinutes(firstTime?.toLong()),
                    TimeUnit.MILLISECONDS.toSeconds
                    (firstTime?.toLong()) -TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(firstTime?.toLong()))))

            Statified.endTime?.setText(String.format("%d: %d",
                    TimeUnit.MILLISECONDS.toMinutes(finalTime?.toLong()),
                    TimeUnit.MILLISECONDS.toSeconds
                    (finalTime?.toLong()) -TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(finalTime?.toLong()))))

            Statified.seekBar?.setProgress(firstTime)
            Handler().postDelayed(Statified.updateSongTime,1000)


        }
        fun onSongComplete(){

            seekBar?.setProgress(0);
            if(Statified.currentSongPlayer?.shuffleSong as Boolean)
            {
                Statified.currentSongPlayer?.isPlaying=true
                playNext("PlayNextNormalShuffle")
            }else {


                if(Statified.currentSongPlayer?.isLoop as Boolean){
                    Statified. currentSongPlayer?.isPlaying=true
                    var nextSong=Statified.fetchList?.get(Statified.currentPosition)
                    Statified.currentSongPlayer?.songPath=nextSong?.details
                    Statified.currentSongPlayer?.songTitle=nextSong?.songTitle
                    Statified.currentSongPlayer?.songArtist=nextSong?.artist
                    Statified.currentSongPlayer?.songId=nextSong?.songId as Long
                    Statified. mediaPlayer?.reset()

                    try {
                        Statified. mediaPlayer?.setDataSource(Statified.mActivity, Uri.parse(Statified.currentSongPlayer?.songPath))
                        Statified.mediaPlayer?.prepare()
                        ProcessInformation(Statified.mediaPlayer as MediaPlayer)
                        Statified. mediaPlayer?.start()

                    }catch (e:Exception){

                        e.printStackTrace()
                    }

                }else{

                    Statified.currentSongPlayer?.isPlaying=true
                    playNext("PlayNextNormal")
                }
            }

            if(Statified.echoDatabase?.checkIfIdExists(Statified.currentSongPlayer?.songId?.toInt() as Int) as Boolean){

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_on)

            }else{

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_off)

            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /*Sensor service is activate when the fragment is created*/
        Statified.mSensorManager = Statified.mActivity?.getSystemService(Context.SENSOR_SERVICE) as SensorManager

        /*Default values*/
        mAcceleration = 0.0f
        /*We take earth's gravitational value to be default, this will give us good results*/
        mAccelerationCurrent = SensorManager.GRAVITY_EARTH
        mAccelerationLast = SensorManager.GRAVITY_EARTH
        /*Here we call the function*/
        bindShakeListener()
    }



    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        var view= inflater.inflate(R.layout.fragment_songs_playing, container, false)
        setHasOptionsMenu(true)
        Statified.shuffleButton=view.findViewById(R.id.shuffle)
        Statified.loopButton=view.findViewById(R.id.loop)
        Statified.playpauseButton=view.findViewById(R.id.play_image)
        Statified.previousButton=view.findViewById(R.id.previous_image)
        Statified.nextButton=view.findViewById(R.id.next_image)
        Statified.songTitle=view.findViewById(R.id.titlesong)
        Statified.songArtist=view.findViewById(R.id.artistsong)
        Statified.startTime=view.findViewById(R.id.start_time)
        Statified.endTime=view.findViewById(R.id.end_time)
        Statified.favButton=view.findViewById(R.id.favorite_icon)
        Statified.favButton?.alpha=0.8f
        Statified.seekBar=view.findViewById(R.id.seekbar)

        Statified.fetchList= ArrayList<Songs>()
        Statified.audioVisualizationView=view.findViewById(R.id.visualizer_view)

        (activity as MainActivity)
                .title="" +
                "Now Playing"


        return  view
    }

     override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
         Statified. audioVisualization=Statified.audioVisualizationView as AudioVisualization
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)

        Statified.mActivity=context as Activity
    }

    override fun onAttach(activity: Activity?) {
        super.onAttach(activity)
        Statified.mActivity=activity
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        Statified.echoDatabase= EchoDatabase(Statified.mActivity as Context)
        Statified.currentSongPlayer= CurrentSongPlayer()

        Statified.currentSongPlayer?.isPlaying = true
        Statified.currentSongPlayer?.isLoop = false
        Statified.currentSongPlayer?.shuffleSong = false
        Statified.currentPosition=arguments?.getInt("songPosition") as Int
        Statified.fetchList=arguments?.getParcelableArrayList("songslist")

        var path:String?=null
        var title:String?=null
        var artist:String?=null
        var id:Long?=0

        try {

            path=arguments?.getString("path")
            title=arguments?.getString("title")
            artist=arguments?.getString("artist")
            id=arguments?.getInt("id")?.toLong()

            Statified.currentSongPlayer?.songPath=path
            Statified.currentSongPlayer?.songTitle=title
            Statified.currentSongPlayer?.songArtist=artist
            Statified.currentSongPlayer?.songId=id as Long
            Statified.currentSongPlayer?.songPosition=Statified.currentPosition

            Staticated.updateTextviews(Statified.currentSongPlayer?.songTitle as String,Statified.currentSongPlayer?.songArtist as String)

        }catch (e:Exception){

             e.printStackTrace()
        }

        //Check song is topped from bottom bar or song

        var favBootomBar=arguments?.getString("FavBottomBar")

        if(favBootomBar!=null){


            Statified.mediaPlayer=FavoriteFragment.Statified.mediaPlayer
        }else {

            Statified.mediaPlayer = MediaPlayer()
            Statified.mediaPlayer?.setAudioStreamType(AudioManager.STREAM_MUSIC)

            try {
                Statified.mediaPlayer?.setDataSource(Statified.mActivity, Uri.parse(path))
                Statified.mediaPlayer?.prepare()

            } catch (e: Exception) {

                e.printStackTrace()
            }

            Statified.mediaPlayer?.start()
        }

        Staticated.ProcessInformation(Statified.mediaPlayer as MediaPlayer)

        Statified.mediaPlayer?.setOnCompletionListener {
            Staticated. onSongComplete()
        }

        clickHandler()

        var visualizationHandler=DbmHandler.Factory.newVisualizerHandler(Statified.mActivity as Context,0)
        Statified.audioVisualization?.linkTo(visualizationHandler)

        var prefsForShuffle=Statified. mActivity?.getSharedPreferences(Staticated.MY_PREFS_SHUFFLE,Context.MODE_PRIVATE)
        var isShuffleAllowed=prefsForShuffle?.getBoolean("feature",false)
        if(isShuffleAllowed as Boolean){
            Statified.currentSongPlayer?.shuffleSong=true
            Statified.currentSongPlayer?.isLoop=false
            Statified.shuffleButton?.setBackgroundResource(R.mipmap.shuffle_icon)
            Statified.loopButton?.setBackgroundResource(R.mipmap.loop_white_icon)

        }else{
            Statified.currentSongPlayer?.shuffleSong=false
            Statified.shuffleButton?.setBackgroundResource(R.mipmap.shuffle_white_icon)
        }


        var prefsForLoop=Statified. mActivity?.getSharedPreferences(Staticated.MY_PREFS_LOOP,Context.MODE_PRIVATE)
        var isLoopAllowed=prefsForLoop?.getBoolean("feature",false)
        if(isLoopAllowed as Boolean){
            Statified.currentSongPlayer?.shuffleSong=false
            Statified.currentSongPlayer?.isLoop=true
            Statified.shuffleButton?.setBackgroundResource(R.mipmap.shuffle_white_icon)
            Statified.loopButton?.setBackgroundResource(R.mipmap.loop_icon)

        }else{
            Statified.currentSongPlayer?.isLoop=false
            Statified.loopButton?.setBackgroundResource(R.mipmap.loop_white_icon)
        }

        if(Statified.echoDatabase?.checkIfIdExists(Statified.currentSongPlayer?.songId?.toInt() as Int) as Boolean){

            Statified.favButton?.setBackgroundResource(R.mipmap.favorite_on)

        }else{

            Statified.favButton?.setBackgroundResource(R.mipmap.favorite_off)

        }
 }


    fun clickHandler()
    {
        Statified.favButton?.setOnClickListener({


            if(Statified.echoDatabase?.checkIfIdExists(Statified.currentSongPlayer?.songId?.toInt() as Int) as Boolean){

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_off)
                Statified.echoDatabase?.deleteValueFromTheDatabase(Statified.currentSongPlayer?.songId?.toInt() as Int)
                Toast.makeText(Statified.mActivity,"Deleted from favorites",Toast.LENGTH_SHORT).show()

            }else{

                Statified.favButton?.setBackgroundResource(R.mipmap.favorite_on)
                Statified.echoDatabase?.storeAsFavorite(Statified.currentSongPlayer?.songId?.toInt(),Statified.currentSongPlayer?.songTitle,Statified.currentSongPlayer?.songArtist
                        ,Statified.currentSongPlayer?.songPath)

                Toast.makeText(Statified.mActivity,"Added to favorites",Toast.LENGTH_SHORT).show()

            }
        })
        Statified.shuffleButton?.setOnClickListener({

            var editorShuffle=Statified.mActivity?.getSharedPreferences(Staticated.MY_PREFS_SHUFFLE,Context.MODE_PRIVATE)?.edit()
            var editorLoop=Statified.mActivity?.getSharedPreferences(Staticated.MY_PREFS_LOOP,Context.MODE_PRIVATE)?.edit()


            if(Statified.currentSongPlayer?.shuffleSong as Boolean){
                Statified.currentSongPlayer?.shuffleSong=false
                Statified.shuffleButton?.setBackgroundResource(R.mipmap.shuffle_white_icon)
                editorShuffle?.putBoolean("feature",false)
                editorShuffle?.apply()

            }else{
                Statified.currentSongPlayer?.shuffleSong=true
                Statified.currentSongPlayer?.isLoop=true
                Statified.loopButton?.setBackgroundResource(R.mipmap.loop_white_icon)
                Statified.shuffleButton?.setBackgroundResource(R.mipmap.shuffle_icon)
                editorShuffle?.putBoolean("feature",true)
                editorShuffle?.apply()
                editorLoop?.putBoolean("feature",false)
                editorLoop?.apply()


            }


        })
        Statified.loopButton?.setOnClickListener({

            var editorShuffle=Statified.mActivity?.getSharedPreferences(Staticated.MY_PREFS_SHUFFLE,Context.MODE_PRIVATE)?.edit()
            var editorLoop=Statified.mActivity?.getSharedPreferences(Staticated.MY_PREFS_LOOP,Context.MODE_PRIVATE)?.edit()


            if(Statified.currentSongPlayer?.isLoop as Boolean){

                Statified.currentSongPlayer?.isLoop=false
                Statified.loopButton?.setBackgroundResource(R.mipmap.loop_white_icon)
                editorLoop?.putBoolean("feature",false)
                editorLoop?.apply()

            }else{
                Statified. currentSongPlayer?.shuffleSong=false
                Statified. currentSongPlayer?.isLoop=true
                Statified.loopButton?.setBackgroundResource(R.mipmap.loop_icon)
                Statified.shuffleButton?.setBackgroundResource(R.mipmap.shuffle_white_icon)
                editorLoop?.putBoolean("feature",true)
                editorLoop?.apply()
                editorShuffle?.putBoolean("feature",false)
                editorShuffle?.apply()

            }

        })
        Statified.playpauseButton?.setOnClickListener({
            if(Statified.mediaPlayer?.isPlaying as Boolean){
                Statified.mediaPlayer?.pause()
                Statified. currentSongPlayer?.isPlaying=false
                Statified.playpauseButton?.setBackgroundResource(R.mipmap.play_icon)
            }else{

                Statified.mediaPlayer?.start()
                Statified.currentSongPlayer?.isPlaying=true
                Statified.playpauseButton?.setBackgroundResource(R.mipmap.pause_icon)
            }

        })
        Statified.previousButton?.setOnClickListener({
            Statified.currentSongPlayer?.isPlaying=true

            if(Statified.currentSongPlayer?.isLoop as Boolean){

                Statified.loopButton?.setBackgroundResource(R.mipmap.loop_white_icon)


            }
            Staticated.playPrevious()


        })
        Statified.nextButton?.setOnClickListener({

            Statified.currentSongPlayer?.isPlaying=true
            if(Statified.currentSongPlayer?.shuffleSong as Boolean){
                Staticated.playNext("PlayNextNormalShuffle")
            }else{
                Staticated.playNext("PlayNextNormal")
            }

        })

        seekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if(fromUser){
                    Statified.mediaPlayer?.seekTo(progress)
                    seekBar.setProgress(progress)


                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Write code to perform some action when touch is started.
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Write code to perform some action when touch is stopped.

            }
        })


    }

    override fun onPause() {
        Statified.audioVisualization?.onPause()
        super.onPause()

        /*When fragment is paused, we remove the sensor to prevent the battery drain*/
        Statified.mSensorManager?.unregisterListener(Statified.mSensorListener)
    }

    override fun onResume() {
        super.onResume()

        Statified. audioVisualization?.onResume()
        Statified.mSensorManager?.registerListener(Statified.mSensorListener,
                Statified.mSensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onDestroy() {
        Statified.audioVisualization?.release()
        Handler().removeCallbacks(Statified.updateSongTime)
        super.onDestroy()
    }


    /*This function handles the shake events in order to change the songs when we shake the phone*/
    fun bindShakeListener() {

        /*The sensor listener has two methods used for its implementation i.e. OnAccuracyChanged() and onSensorChanged*/
        Statified.mSensorListener = object : SensorEventListener {
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {

                /*We do noot need to check or work with the accuracy changes for the sensor*/
            }

            override fun onSensorChanged(event: SensorEvent) {

                /*We need this onSensorChanged function
                * This function is called when there is a new sensor event*/
                /*The sensor event has 3 dimensions i.e. the x, y and z in which the changes can occur*/
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]

                /*Now lets see how we calculate the changes in the acceleration*/
                /*Now we shook the phone so the current acceleration will be the first to start with*/
                mAccelerationLast = mAccelerationCurrent

                /*Since we could have moved the phone in any direction, we calculate the Euclidean distance to get the normalized distance*/
                mAccelerationCurrent = Math.sqrt(((x * x + y * y + z * z).toDouble())).toFloat()

                /*Delta gives the change in acceleration*/
                val delta = mAccelerationCurrent - mAccelerationLast

                /*Here we calculate thelower filter
                * The written below is a formula to get it*/
                mAcceleration = mAcceleration * 0.9f + delta

                /*We obtain a real number for acceleration
                * and we check if the acceleration was noticeable, considering 12 here*/
                if (mAcceleration > 12) {

                    /*If the accel was greater than 12 we change the song, given the fact our shake to change was active*/
                    val prefs = Statified.mActivity?.getSharedPreferences(Statified.MY_PREFS_NAME, Context.MODE_PRIVATE)
                    val isAllowed = prefs?.getBoolean("feature", false)
                    if (isAllowed as Boolean) {
                        Staticated.playNext("PlayNextNormal")
                    }
                }
            }
        }
    }


        //This function is used to create the menu
        override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
                menu?.clear()
                inflater?.inflate(R.menu.song_playing_menu, menu)
                super.onCreateOptionsMenu(menu, inflater)
        }
        override fun onPrepareOptionsMenu(menu: Menu?) {
            super.onPrepareOptionsMenu(menu)
                val item: MenuItem? = menu?.findItem(R.id.redirect)
                item?.isVisible = true
        }
        ///Here we handle the click event of the menu item
        override fun onOptionsItemSelected(item: MenuItem?): Boolean {
            when (item?.itemId) {

                R.id.redirect -> {
                    Statified.mActivity?.onBackPressed()
                    return false
                }
            }
            return false
        }


}
