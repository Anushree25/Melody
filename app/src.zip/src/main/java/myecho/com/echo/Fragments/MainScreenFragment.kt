package myecho.com.echo.Fragments


import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.provider.MediaStore
import android.support.v4.app.Fragment
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.*
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.TextView
import myecho.com.echo.Adapters.MainScreenAdapter
import myecho.com.echo.Adapters.NavigationDrawerAdapter
import myecho.com.echo.MainActivity
import myecho.com.echo.R
import myecho.com.echo.Songs
import java.util.*


class MainScreenFragment : Fragment() {

    var musicplayerlayout:RelativeLayout?=null
    object Statified {
        var recyclerViewSongs: RecyclerView? = null
    }
    var songsplayingvisiblelayout:RelativeLayout?=null
    var songsnotavailablelayout:RelativeLayout?=null
    var songTitle:TextView?=null
    var playpausebutton:ImageButton?=null
    var mActivity:Activity?=null
    var mainScreenAdapter: MainScreenAdapter? = null

    var trackPosition=0
    var getSongsList:ArrayList<Songs>?=null



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        val view=inflater.inflate(R.layout.fragment_main_screen, container, false)
        setHasOptionsMenu(true)
        musicplayerlayout=view.findViewById(R.id.music_player_menu)
        Statified.recyclerViewSongs=view.findViewById(R.id.songs_list)
        songsplayingvisiblelayout=view.findViewById(R.id.visiblelayout)
        songsnotavailablelayout=view.findViewById(R.id.invisiblelayout)
        playpausebutton=view.findViewById(R.id.pause_button)
        songTitle=view.findViewById(R.id.song_title)


        (activity as MainActivity)
                .title="All Songs"

        return view
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        mActivity=context as Activity
    }

    override fun onAttach(activity: Activity?) {
        super.onAttach(activity)
        mActivity=activity
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        getSongsList=getSongsFromThePhone()
       //Declaring the preferences to save the sorting order which we select*/
        val prefs = activity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)
        val action_sort_ascending = prefs?.getString("action_sort_ascending", "true")
        val action_sort_recent = prefs?.getString("action_sort_recent", "false")
        //If there are no songs we do not display the list instead we display no songs message*/
        if (getSongsList == null) {
            songsplayingvisiblelayout?.visibility = View.INVISIBLE
            songsnotavailablelayout?.visibility = View.VISIBLE
        }
        //If there are songs in the device, we display the list*/
        else {

            mainScreenAdapter = MainScreenAdapter(getSongsList as ArrayList<Songs>, mActivity as Context)

            val mLayoutManager = LinearLayoutManager(mActivity)
            Statified.recyclerViewSongs?.layoutManager = mLayoutManager
            Statified.recyclerViewSongs?.itemAnimator = DefaultItemAnimator()
            Statified.recyclerViewSongs?.adapter = mainScreenAdapter
        }
        /*If the songs list is not empty, then we check whether applied any comparator
        * And we use that comparator and sort the list accordingly*/
        if (getSongsList != null) {
            if (action_sort_ascending!!.equals("true", ignoreCase = true)) {
                Collections.sort(getSongsList, Songs.Statified.nameComparator)
                mainScreenAdapter?.notifyDataSetChanged()
            } else if (action_sort_recent!!.equals("true", ignoreCase = true)) {
                Collections.sort(getSongsList, Songs.Statified.dateComparator)
                mainScreenAdapter?.notifyDataSetChanged()
            }
        }

    bottomBarSetup()

    }

    fun getSongsFromThePhone():ArrayList<Songs>{

        var songs=ArrayList<Songs>()
        var contentResolver=mActivity?.contentResolver
        var songuri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        var songcursor=contentResolver?.query(songuri,null,null,null,null)

        if(songcursor!=null && songcursor.moveToFirst()) {
            var songId = songcursor.getColumnIndex(MediaStore.Audio.Media._ID)
            var songtitle = songcursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
            var songArtist = songcursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
            var songDetails = songcursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            var songeDate = songcursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)

            while (songcursor.moveToNext()) {
                var id = songcursor.getLong(songId)
                var title = songcursor.getString(songtitle)
                var artist = songcursor.getString(songArtist)
                var details = songcursor.getString(songDetails)
                var date = songcursor.getLong(songeDate)

                songs.add(Songs(id, title, artist, details, date))

            }


        }


        return songs
    }


    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        menu?.clear()
        inflater?.inflate(R.menu.main, menu)

        return
    }

    override fun onPrepareOptionsMenu(menu: Menu?) {
        super.onPrepareOptionsMenu(menu)


    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val switcher = item?.itemId
        if (switcher == R.id.sort_by_name) {
            /*Whichever action item is selected, we save the preferences and perform the operation of comparison*/
            val editor = mActivity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
            editor?.putString("action_sort_ascending", "true")
            editor?.putString("action_sort_recent", "false")
            editor?.apply()
            if (getSongsList != null) {
                Collections.sort(getSongsList, Songs.Statified.nameComparator)
            }
            mainScreenAdapter?.notifyDataSetChanged()
            return false
        } else if (switcher == R.id.sort_recent_items) {
            val editortwo = mActivity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
            editortwo?.putString("action_sort_recent", "true")
            editortwo?.putString("action_sort_ascending", "false")
            editortwo?.apply()
            if (getSongsList != null) {
                Collections.sort(getSongsList, Songs.Statified.dateComparator)
            }
            mainScreenAdapter?.notifyDataSetChanged()
            return false
        }
        return super.onOptionsItemSelected(item)
    }

    fun bottomBarSetup(){

        bottomBarClickHandler()
        try {

            songTitle?.setText(SongsPlayingFragment.Statified.currentSongPlayer?.songTitle)

            if( SongsPlayingFragment.Statified.mediaPlayer !=null) {
                SongsPlayingFragment.Statified.mediaPlayer?.setOnCompletionListener {

                    songTitle?.setText(SongsPlayingFragment.Statified.currentSongPlayer?.songTitle)
                    SongsPlayingFragment.Staticated.onSongComplete()

                }
                if (SongsPlayingFragment.Statified.mediaPlayer?.isPlaying as Boolean) {

                    musicplayerlayout?.visibility = View.VISIBLE
                } else {

                    musicplayerlayout?.visibility = View.INVISIBLE
                }
            }
        }catch (e:Exception){

            e.printStackTrace()

        }


    }

    fun bottomBarClickHandler(){


        musicplayerlayout?.setOnClickListener {

            FavoriteFragment.Statified.mediaPlayer=SongsPlayingFragment.Statified.mediaPlayer

            val songsPlayingFragment= SongsPlayingFragment()
            var obj=Bundle()
            obj.putString("artist",SongsPlayingFragment.Statified.currentSongPlayer?.songArtist)
            obj.putString("path",SongsPlayingFragment.Statified.currentSongPlayer?.songPath)
            obj.putString("title",SongsPlayingFragment.Statified.currentSongPlayer?.songTitle)
            obj.putInt("id",SongsPlayingFragment.Statified.currentSongPlayer?.songId?.toInt() as Int)
            obj.putInt("songPosition",SongsPlayingFragment.Statified.currentSongPlayer?.songPosition?.toInt() as Int)
            obj.putParcelableArrayList("songslist",getSongsList)
            songsPlayingFragment.arguments=obj

            obj.putString("FavBottomBar","success")

            fragmentManager?.beginTransaction()?.replace(R.id.details_fragment,songsPlayingFragment)
                    ?.addToBackStack("SongsPlayingFragment")?.commit()



        }

        playpausebutton?.setOnClickListener({
            if(SongsPlayingFragment.Statified.mediaPlayer?.isPlaying as Boolean){
                SongsPlayingFragment.Statified.mediaPlayer?.pause()
                trackPosition=SongsPlayingFragment.Statified.currentSongPlayer?.songPosition?.toInt() as Int
                playpausebutton?.setBackgroundResource(R.mipmap.play_icon)
            }else{

                SongsPlayingFragment.Statified.mediaPlayer?.seekTo(trackPosition)
                SongsPlayingFragment.Statified.mediaPlayer?.start()
                playpausebutton?.setBackgroundResource(R.mipmap.pause_icon)
            }

        })

    }

}
